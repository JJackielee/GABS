//
//  interestPointsViewController.swift
//  scaffolding
//
//  Created by Jackie Lee on 3/4/17.
//  Copyright © 2017 Ruth Featherston. All rights reserved.
//

import UIKit
import MapKit

class interestPointsViewController: BaseViewController {
    
    var lat : Double!
    var lng : Double!
    var name : String!
    @IBOutlet weak var mapView: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.navigationItem.title = "Add Interest Point"
        print(lat)
        print(lng)
        
        let span = MKCoordinateSpanMake(0.005, 0.005)
         let coord2 = CLLocationCoordinate2D(latitude: (lat + 0.0015), longitude: lng)
        let coord = CLLocationCoordinate2D(latitude: lat, longitude: lng)
        let region = MKCoordinateRegion(center: coord2, span: span)
        mapView.setRegion(region, animated: false)
        
        let annotation = Interestpoints(title: name, coordinate: coord)
        mapView.addAnnotation(annotation)
        
        
        let hi = UIBarButtonItem(title: "Save", style: .plain, target: self , action: "dothis")
        let button = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.refresh, target: self, action: "dothis")
        navigationItem.rightBarButtonItem = hi

        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func dothis(){
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
