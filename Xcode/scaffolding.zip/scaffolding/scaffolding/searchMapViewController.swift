//
//  ViewController.swift
//  MapKitTutorial
//
//  Created by Robert Chen on 12/23/15.
//  Copyright © 2015 Thorn Technologies. All rights reserved.
//

import UIKit
import MapKit

protocol HandleMapSearch: class {
    func dropPinZoomIn(_ placemark:MKPlacemark)
}

class searchMapViewController: BaseViewController
{
    
    
    
    var selectedPin: MKPlacemark?
    var resultSearchController: UISearchController!
    
    var long: [Double] = []
    var lat: [Double] = []
    var time:[String] = []
    var gunId: [Int] = []
    
    var timer = Timer()
    var selectedAnnotation : Gunshots!
    var selectedAnnotation2 : Interestpoints!
    
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var mapView: MKMapView!
    
    // @IBAction func button3(_ sender: AnyObject) {
    //   getDirections()
    //}
    
    
    override func viewDidLoad()
    {
        
        
        //add hamburger menu button
        addSlideMenuButton()
        super.viewDidLoad()
        mapView.showsUserLocation = true
        mapView.tintColor = UIColor.blue
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        
        
        let locationSearchTable = storyboard!.instantiateViewController(withIdentifier: "LocationSearchTable") as! LocationSearchTable
        
        resultSearchController = UISearchController(searchResultsController: locationSearchTable)
        resultSearchController.searchResultsUpdater = locationSearchTable
        
        //refreshbutton
        
        let button = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.refresh, target: self, action: "refreshLoc")
        navigationItem.rightBarButtonItem = button
        
        let searchBar = resultSearchController!.searchBar
        searchBar.sizeToFit()
        searchBar.placeholder = "Search Address"
        navigationItem.titleView = resultSearchController?.searchBar
        resultSearchController.hidesNavigationBarDuringPresentation = false
        resultSearchController.dimsBackgroundDuringPresentation = true
        definesPresentationContext = true
        locationSearchTable.mapView = mapView
        locationSearchTable.handleMapSearchDelegate = self
        
        
        getData()
        
    }
    func refreshLoc(){
        locationManager.requestLocation()
        getData()
    }
    
    func getData()
    {
        self.long.removeAll()
        self.lat.removeAll()
        self.time.removeAll()
        self.gunId.removeAll()
        mapView.removeAnnotations(mapView.annotations)
        let mapEndpoint: String = "http://students.washington.edu/nguy923/GABS/shots%20data/shotdatas"
        guard let url = URL(string: mapEndpoint) else
        {
            print("Error: cannot create URL")
            return
        }
        
        let urlRequest = URLRequest(url: url)
        
        // set up the session
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        
        // make the request
        
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /todos/1")
                print(error)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON, since that's what the API provides
            do {
                guard
                    let data = try JSONSerialization.jsonObject(with: responseData, options: JSONSerialization.ReadingOptions.allowFragments) as? [String : NSArray]
                    
                    else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo, let's just print it to prove we can access it
                print("The data is: " + data.description)
                if let arrJSON = data["ShotsData"] {
                    for index in 0...arrJSON.count-1 {
                        
                        let aObject = arrJSON[index] as! [String : AnyObject]
                        
                        self.long.append(aObject["lng"] as! Double)
                        self.lat.append(aObject["lat"] as! Double)
                        self.time.append(aObject["time"] as! String)
                        self.gunId.append(aObject["id"] as! Int)
                        
                    }
                }
                //updates the map with markers after it recieve json code.
                self.updateMap()
                
                
                
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        task.resume()
    }
    
    func updateMap(){
        DispatchQueue.main.async { () -> Void in
            
            
            for i in 0...self.long.count-1{
                let array = self.time[i].components(separatedBy: "T")
                var time2 = "hi"
                if(!array.isEmpty){
                    time2 = self.getTime(date: array[0], time: array[1])
                }else {
                    time2 = "something wrote with database"
                }
                
                let pin = Gunshots(title: "GunShot Detected", coordinate: CLLocationCoordinate2D(latitude: self.lat[i], longitude: self.long[i]),time: time2,id:self.gunId[i])
                self.mapView.addAnnotation(pin)
            }
            
        }
        
    }
    func getTime(date: String, time:String) -> String{
        var hour : Int!
        var ampm = " PM"
        var timeArray = time.components(separatedBy: ":")
        var dateArray = date.components(separatedBy: "-")
        if((Int(timeArray[0])! < 12)){
            ampm = " AM"
            if((Int(timeArray[0])! == 0)){
                hour = 12
            } else{
                hour = Int(timeArray[0])
            }
        } else {
            if((Int(timeArray[0])! != 12)){
                hour = Int(timeArray[0])! - 12
            } else {
                hour = 12
            }
        }
        
        
        var fdate = "Date: " + dateArray[1]+"/"+dateArray[2]+"/"+dateArray[0]
        var fTime : String = "    Time: " + String(hour) + ":" + timeArray[1]
        return fdate + fTime + ampm
    }

    
    
    
    
func getDirections()
    {
        guard let selectedPin = selectedPin else { return }
        let mapItem = MKMapItem(placemark: selectedPin)
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        mapItem.openInMaps(launchOptions: launchOptions)
    }
}
    

extension searchMapViewController : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location.coordinate, span: span)
        mapView.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error:: \(error)")
    }
    
}

extension searchMapViewController: HandleMapSearch {
    
    func dropPinZoomIn(_ placemark: MKPlacemark){
        // cache the pin
        selectedPin = placemark
        // clear existing pins
        mapView.removeAnnotations(mapView.annotations)
        updateMap()
        let annotation = Interestpoints(title: placemark.name!, coordinate: placemark.coordinate)
        
        if let city = placemark.locality,
            let state = placemark.administrativeArea {
            annotation.subtitle = "\(city) \(state)"
        }
        
        mapView.addAnnotation(annotation)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegionMake(placemark.coordinate, span)
        mapView.setRegion(region, animated: true)
    }
    
}

extension searchMapViewController : MKMapViewDelegate
{
    
    //in order to make this work. i had to ctrl drag mapview to viewcontroller delegate and activate map capalities.
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 1
        let identifier = "hai"
        
        // 2
        if annotation is Gunshots {
            // 3
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            
            if annotationView == nil {
                //4
                annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                annotationView!.canShowCallout = true
                
                // 5
                let btn = UIButton(type: .detailDisclosure)
                annotationView!.rightCalloutAccessoryView = btn
            } else {
                // 6
                annotationView!.annotation = annotation
            }
            
            return annotationView
        }
        if annotation is Interestpoints {
            // 3
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "bai")
            
            if annotationView == nil {
                //4
                annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "bai")
                annotationView!.canShowCallout = true
                
                // 5
                let btn = UIButton(type: .contactAdd)
                annotationView!.rightCalloutAccessoryView = btn
            } else {
                // 6
                annotationView!.annotation = annotation
            }
            
            return annotationView
        }
        
        // 7
        return nil
    }
    
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl)
    {
        /*let capital = view.annotation as! Capital
         let placeName = capital.title
         let placeInfo = capital.info
         
         let ac = UIAlertController(title: placeName, message: placeInfo, preferredStyle: .alert)
         ac.addAction(UIAlertAction(title: "OK", style: .default))
         present(ac, animated: true)*/
        if control == view.rightCalloutAccessoryView
        {
            if( view.reuseIdentifier == "hai"){
            selectedAnnotation = view.annotation as! Gunshots!
            performSegue(withIdentifier: "detailView", sender: view)
            } else {
                if(!UserDefaults.standard.bool(forKey: "isUserLoggedIn")){
                    DispatchQueue.main.async { () -> Void in
                        var myAlert = UIAlertController(title: "Error" , message: "Only logged in users can add interest points", preferredStyle: UIAlertControllerStyle.alert);
                        
                        // goes back to previous screen when pressed okay
                        let okAction = UIAlertAction(title:"ok",style:UIAlertActionStyle.default)
                        
                        // adds okay action
                        myAlert.addAction(okAction)
                        //shows the alert
                        self.present(myAlert, animated:true, completion:nil)
                    }

                    
                } else {
                    selectedAnnotation2 = view.annotation as! Interestpoints!
                    performSegue(withIdentifier: "addInterest", sender: view)
                }
                
            }
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "detailView")
        {
            if let details = segue.destination as? detailPinViewController
            {
                details.time = selectedAnnotation.time!
                details.id = selectedAnnotation.id
                details.lat = selectedAnnotation.coordinate.latitude
                details.lng = selectedAnnotation.coordinate.longitude
                
            }
        }
        if(segue.identifier == "addInterest")
        {
            if let details = segue.destination as? interestPointsViewController
            {
                details.lat = selectedAnnotation2.coordinate.latitude
                details.lng = selectedAnnotation2.coordinate.longitude
                details.name = selectedAnnotation2.title
                
            }
        }
    }
    
    

}

