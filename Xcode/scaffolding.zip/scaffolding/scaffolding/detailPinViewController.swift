//
//  detailPinViewController.swift
//  GABS
//
//  Created by Jackie Lee on 2/20/17.
//  Copyright © 2017 Jackie Lee. All rights reserved.
//

import UIKit
import MapKit



class detailPinViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate
 {
    //misc
    @IBOutlet weak var sortButton: UIButton!
    @IBOutlet weak var addCommentButton: UIButton!
    
    //comment stuff
    let comments = ["Testing comment 1: This is a supposed to be an example of a 140? character limit. Number of characters should be user tested later on.......", "We should also set a char limit for the username, to determine the maximum amount of spacing needed between the username lbl and time label.", "Those weird triangle things on the side are just placeholders for possible buttons. # count between them?", "This is a comment to show that this page scrolls when there's quite a bit on content. Notes: 3 lines may be the maximum number of lines?"]
    let usernames = ["BadgeringBob", "DebbieDowner", "NegativeNancy", "ScreamingSusie"]
    let timestamps = ["00:00 AM", "00:20 PM", "01:23 AM", "11:11 PM"]
  
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (comments.count)
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentTableViewCell", for: indexPath) as! commentTableViewCell
        
        cell.commentTableView.text = comments[indexPath.item]
        cell.usernameLbl.text = usernames[indexPath.item]
        cell.timeLbl.text = timestamps[indexPath.item]
        
        return cell
    }
    
    let URL_INPUT = "http://students.washington.edu/nguy923/ios/cdd/getinput.php"
    let URL_COUNT = "http://students.washington.edu/nguy923/ios/cdd/countinput.php"
    let URL_CHECK = "http://students.washington.edu/nguy923/ios/cdd/checkcdd.php"
    
    @IBOutlet weak var mapView: MKMapView!
    var time: String = ""
    var id: Int = 0
    var lat : Double!
    var lng : Double!
    
    var cJson = 0
    var dJson = 0
    var dkJson = 0
    
    @IBOutlet weak var confirmLabel: UILabel!
    @IBOutlet weak var denyLabel: UILabel!
    @IBOutlet weak var dkLabel: UILabel!

    @IBOutlet weak var confirm: UIButton!
    @IBOutlet weak var dent: UIButton!
    @IBOutlet weak var dk: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let span = MKCoordinateSpanMake(0.005, 0.005)
        let coord = CLLocationCoordinate2D(latitude: lat, longitude: lng)
        let coord2 = CLLocationCoordinate2D(latitude: (lat + 0.0015), longitude: lng)
        let region = MKCoordinateRegion(center: coord2, span: span)
        mapView.setRegion(region, animated: false)
        
        let annotation = Interestpoints(title: time, coordinate: coord)
        mapView.addAnnotation(annotation)
        
        getCount()
        
        
        
        
        if(!UserDefaults.standard.bool(forKey: "isUserLoggedIn")){
            self.confirm.isEnabled = false
            self.dent.isEnabled = false
            self.dk.isEnabled = false
            confirm.backgroundColor = UIColor.gray
            dent.backgroundColor = UIColor.gray
            dk.backgroundColor = UIColor.gray
            var myAlert = UIAlertController(title: "Hint" , message: "Log in to be able to confirm!", preferredStyle: UIAlertControllerStyle.alert);
            let okAction = UIAlertAction(title:"ok",style:UIAlertActionStyle.default)
            //adds actions
            myAlert.addAction(okAction)
            self.present(myAlert, animated:true, completion:nil)

        } else{
            checkButtons()
        }
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func confirmButton(_ sender: UIButton)
    {
        sendInput(input:"Confirm")
    }
    @IBAction func denyButton(_ sender: UIButton)
    {
        sendInput(input:"Deny")
    }
    @IBAction func dkButton(_ sender: UIButton)
    {
         sendInput(input:"DontKnow")
    }
    
    func sendInput(input:String){
        guard let url = URL(string: URL_INPUT) else {
            print("Error: cannot create URL")
            return
        }
        var urlRequest = URLRequest(url: url)
        //created NSURL
        //setting the method to post
        urlRequest.httpMethod = "POST"
        let idString : String = String(id)
        let idAccount : String = UserDefaults.standard.value(forKey: "userId") as! String
        //creating the post parameter by concatenating the keys and values from text field
        let postParameters = "id="+idString+"&user="+idAccount+"&input="+input;
        print(postParameters)
        //adding the parameters to request body
        urlRequest.httpBody = postParameters.data(using: .utf8)
        //creating a task to send the post request
        let task = URLSession.shared.dataTask(with:urlRequest){
            data, response, error in
            if error != nil{
                print("error is \(error)")
                return;
            }
            //parsing the response
            do {
                //converting resonse to NSDictionary
                let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                //parsing the json
                if let parseJSON = myJSON {
                    //creating a string
                    var msg : String!
                    //getting the json response
                    msg = parseJSON["message"] as! String?
                    //printing the response
                    print(msg)
                    self.getCount()
                    self.checkButtons()
                }
            } catch {
                print(error)
            }
        }
        //executing the task
        task.resume()
    }
    
    func getCount(){
        guard let url = URL(string: URL_COUNT) else {
            print("Error: cannot create URL")
            return
        }
        var urlRequest = URLRequest(url: url)
        
        //created NSURL
        
        //setting the method to post
        urlRequest.httpMethod = "POST"
        
        let idString : String = String(id)
        
        //creating the post parameter by concatenating the keys and values from text field
        let postParameters = "id="+idString;
        
        //adding the parameters to request body
        urlRequest.httpBody = postParameters.data(using: .utf8)
        
        
        //creating a task to send the post request
        
        let task = URLSession.shared.dataTask(with:urlRequest){
            data, response, error in
            
            if error != nil{
                print("error is \(error)")
                return;
            }
            
            //parsing the response
            do {
                //converting resonse to NSDictionary
                
                let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                //parsing the json
                if let parseJSON = myJSON {
                    
                    //creating a string
                    //getting the json response
                    self.cJson = (parseJSON["Confirm"] as! Int?)!
                    self.dJson = (parseJSON["Deny"] as! Int?)!
                    self.dkJson = (parseJSON["DontKnow"] as! Int?)!
                    print(self.cJson)
                    self.updateLabel()
                }
            } catch {
                print(error)
            }
            
        }
        //executing the task
        task.resume()
        
        
        
        
    }
    func updateLabel(){
        DispatchQueue.main.async { () -> Void in
            self.confirmLabel.text = String(self.cJson)
            self.denyLabel.text = String(self.dJson)
            self.dkLabel.text = String(self.dkJson)
        }
    }
    
    func checkButtons(){
        var didPick : Bool = true
        var whatPick : String = ""
        
        guard let url = URL(string: URL_CHECK) else {
            print("Error: cannot create URL")
            return
        }
        let idAccount : String = UserDefaults.standard.value(forKey: "userId") as! String
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        let idString : String = String(id)
        let postParameters = "id="+idString+"&user="+idAccount
        print(postParameters)
        urlRequest.httpBody = postParameters.data(using: .utf8)
        let task = URLSession.shared.dataTask(with:urlRequest){
            data, response, error in
            if error != nil{
                print("error is \(error)")
                return;
            }
                do {
                let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                if let parseJSON = myJSON {
                    didPick = (parseJSON["empty"] as! Bool?)!
                    whatPick = (parseJSON["message"] as! String?)!
                    if(!didPick){
                        self.disableBut(cdd: whatPick)
                    }
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    func disableBut(cdd : String){
        DispatchQueue.main.async { () -> Void in

            self.confirm.isEnabled = false
            self.dent.isEnabled = false
            self.dk.isEnabled = false
        
            if(cdd == "Confirm"){
               self.dk.backgroundColor = UIColor.gray
                self.dent.backgroundColor = UIColor.gray
            } else if (cdd == "Deny"){
                self.confirm.backgroundColor = UIColor.gray
                self.dk.backgroundColor = UIColor.gray
            } else{
                self.confirm.backgroundColor = UIColor.gray
                self.dent.backgroundColor = UIColor.gray
            }
        }

        
    }
}
