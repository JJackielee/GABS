//
//  commentTableViewCell.swift
//  Comments
//
//  Created by Ruth Featherston on 3/4/17.
//  Copyright © 2017 Ruth Featherston. All rights reserved.
//

import UIKit

class commentTableViewCell: UITableViewCell
{
    
    @IBOutlet weak var commentTableView: UITextView!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    @IBAction func upVoteButton(_ sender: Any) {
    }
    @IBAction func downVoteButton(_ sender: Any) {
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
