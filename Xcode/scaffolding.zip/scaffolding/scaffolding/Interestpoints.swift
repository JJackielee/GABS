//
//  Interestpoints.swift
//  scaffolding
//
//  Created by Jackie Lee on 3/4/17.
//  Copyright © 2017 Ruth Featherston. All rights reserved.
//

import UIKit
import MapKit

class Interestpoints: NSObject,MKAnnotation {
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var subtitle: String?
    
    init(title: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
    }

}
